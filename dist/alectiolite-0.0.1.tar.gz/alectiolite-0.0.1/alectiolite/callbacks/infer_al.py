import os
from alectiolite.callbacks import Callback



class InferAL(Callback):


	def on_infer_begin(self,infer_outputs ,use_case):
		pass


	def on_infer_begin(self,infer_outputs ,use_case):
		pass








