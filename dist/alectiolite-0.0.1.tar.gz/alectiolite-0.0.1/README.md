# Alectiolite
New SDK format <br />


# Brief instructions 
conda create -n myenv python=3.6 <br />
conda activate myenv<br />





## TODO 
- creating docstrings <br />
