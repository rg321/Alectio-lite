from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from .default_backend_config import _C as backend_config
from .default_backend_config import update_backend_config



__all__ = ['backend_config',
           'update_backend_config',
           ]
